####
	###项目说明
		# iOS 原生项目

	### branch & tag
		说明
			# 0.1.0 (branch)
					1.创建了工程
					2.设置App icon 设置了APP 启动图 做了 APP基础适配
					3.设置tabbar/navbar导航结构(系统)
						TODO 自定义tabbar/自定义navbar
			# v0.1.0 (tag)
					1.创建了工程
					2.设置App icon 设置了APP 启动图 做了 APP基础适配
					3.设置tabbar/navbar导航结构(系统)

			# v0.2.0 (tag)
					地图的基础使用-MKMapView
					链接: https://www.jianshu.com/p/5f0a478738e7

			# 0.3.0 (branch) 
					1.工程用Carthage（替换cocoaPods）
					地址：Carthage https://github.com/Carthage/Carthage
					参考：https://www.jianshu.com/p/f33972b08648
					
					2.导入MyLinearLayout库
					MyLinearLayout 布局库
					地址 https://github.com/youngsoft/MyLinearLayout
						2.1工程中增加了视图尺寸、导航栏等相关宏定义
						2.2 
							a.采用手工方式导入，正常使用
							b.采用carthage方式导入成功了，感谢欧阳大哥的更新，（MyLinearLayout tag 1.5.3 carthage导入是失败的，tag 1.5.4 采用 carthage 方式导入工程是成功的）
							c.本地cocapods 无法导入最新版本
						2.3布局
							TODO 有空可以练习下，线性布局
							链接：https://blog.csdn.net/yangtiang/article/details/46483999
						TODO 练习别的布局MyLinearLayout中的
			# 0.4.0 (branch)
				TODO 练习AutoLayout/Size class
						 练习Masonry
						 链接：https://www.jianshu.com/p/c12eb90b16fc

			# v0.5.0 测试系统分享功能
				UIActivityViewController 系统分享功能

			# v0.5.1 文件操作
				参考 url: https://www.jianshu.com/p/e3461a905a14
				FileViewController 

				// 创建本地文件 并分享 
				FileMgrViewController 

				遇到权限问题 url： https://blog.csdn.net/qq_22080737/article/details/56844900

				UIActivityViewController 调用系统分享，分享文字，图片 url,
				UIDocumentInteractionController 分享和预览文件

			# v0.6.0 照片压缩
				拍照、相册、视频压缩
			
			# v0.7.0 内存泄露 
				a. Address Sanitizer 应用

				b. MLeaksFinder 使用
					https://github.com/Tencent/MLeaksFinder

				c. FBRetainCycleDetector 使用
					https://github.com/facebook/FBRetainCycleDetector