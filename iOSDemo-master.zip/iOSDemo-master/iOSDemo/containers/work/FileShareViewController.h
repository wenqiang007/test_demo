//
//  FileShareViewController.h
//  iOSDemo
//
//  Created by qixin on 2018/8/6.
//  Copyright © 2018年 qixin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FileShareViewController : UIViewController<UIDocumentInteractionControllerDelegate>

@end
